import view.StudentView;

public class MainApp {
    public static void main(String[] args) {
        StudentView studentView = new StudentView();
        studentView.displayMenu();
    }
}