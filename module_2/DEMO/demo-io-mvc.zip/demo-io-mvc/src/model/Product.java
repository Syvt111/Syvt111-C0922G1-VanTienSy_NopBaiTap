package model;

public class Product {
}
